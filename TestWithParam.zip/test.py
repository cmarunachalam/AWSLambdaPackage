import json

def lambda_handler(event, context):
    # TODO implement
    message = '{} {}!'.format(event['firstname'], event['lastname']) 
    return {
        'statusCode': 200,
        'body': message
    }

